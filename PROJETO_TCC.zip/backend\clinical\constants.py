DIAGNOSTIC_AXES = [
    {
        'id': 'mchat',
        'label': 'M-CHAT',
        'questions': [
            {'id': 'mchat_01', 'text': 'Seu filho gosta de ser balançado, de pular no seu joelho etc.?'},
            {'id': 'mchat_02', 'text': 'Seu filho tem interesse por outras crianças?'},
            {'id': 'mchat_03', 'text': 'Seu filho gosta de subir em coisas, como escadas ou móveis?'},
            {'id': 'mchat_04', 'text': 'Seu filho gosta de brincar de esconder e mostrar o rosto ou de esconde-esconde?'},
            {'id': 'mchat_05', 'text': 'Seu filho já brincou de faz-de-conta (por exemplo, falar ao telefone ou cuidar de uma boneca)?'},
            {'id': 'mchat_06', 'text': 'Seu filho já usou o dedo indicador para apontar e pedir alguma coisa?'},
            {'id': 'mchat_07', 'text': 'Seu filho já usou o dedo indicador para apontar e indicar interesse em algo?'},
            {'id': 'mchat_08', 'text': 'Seu filho consegue brincar corretamente com brinquedos pequenos (por exemplo, carrinhos ou blocos)?'},
            {'id': 'mchat_09', 'text': 'Seu filho já trouxe objetos para mostrar a você apenas por querer mostrar?'},
            {'id': 'mchat_10', 'text': 'Seu filho olha para você nos olhos por mais de um ou dois segundos?'},
            {'id': 'mchat_11', 'text': 'Seu filho já pareceu muito sensível a barulhos (por exemplo, tapando os ouvidos ou chorando)?'},
            {'id': 'mchat_12', 'text': 'Seu filho sorri em resposta ao seu rosto ou ao seu sorriso?'},
            {'id': 'mchat_13', 'text': 'Seu filho imita você (por exemplo, fazer caretas ou copiar gestos)?'},
            {'id': 'mchat_14', 'text': 'Seu filho responde quando você o chama pelo nome?'},
            {'id': 'mchat_15', 'text': 'Se você aponta um brinquedo do outro lado do cômodo, seu filho olha para ele?'},
            {'id': 'mchat_16', 'text': 'Seu filho já sabe andar?'},
            {'id': 'mchat_17', 'text': 'Seu filho olha para coisas que você está olhando?'},
            {'id': 'mchat_18', 'text': 'Seu filho faz movimentos estranhos com os dedos perto do rosto?'},
            {'id': 'mchat_19', 'text': 'Seu filho tenta atrair a sua atenção para a atividade dele?'},
            {'id': 'mchat_20', 'text': 'Você alguma vez já se perguntou se seu filho é surdo?'},
            {'id': 'mchat_21', 'text': 'Seu filho entende o que as pessoas dizem?'},
            {'id': 'mchat_22', 'text': 'Seu filho às vezes fica aéreo, olhando para o nada ou caminhando sem direção definida?'},
            {'id': 'mchat_23', 'text': 'Seu filho olha para o seu rosto para conferir a sua reação quando vê algo estranho?'},
        ],
    },
]


DIAGNOSTIC_QUESTIONS = [
    {**question, 'axis': axis['label']}
    for axis in DIAGNOSTIC_AXES
    for question in axis['questions']
]

DIAGNOSTIC_RECOMMENDATIONS = {
    'severe': 'Risco alto segundo M-CHAT. Recomenda-se encaminhamento imediato para avaliação especializada multidisciplinar.',
    'moderate': 'Risco moderado segundo M-CHAT. Reaplique o M-CHAT-R/F com entrevista e monitore intervenções precoces.',
    'mild': 'Baixo risco segundo M-CHAT. Continue acompanhamento do desenvolvimento e repita o rastreio periodicamente.',
}
